#include <stdio.h>

int main() {
    printf("Hello, Windows!\n");
    return 0;
}

