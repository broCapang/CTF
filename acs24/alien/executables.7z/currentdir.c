#include <windows.h>
#include <stdio.h>

int main() {
    char buffer[MAX_PATH];
    if (GetCurrentDirectory(MAX_PATH, buffer)) {
        printf("Current Working Directory: %s\n", buffer);
    } else {
        printf("Failed to get current directory.\n");
    }
    return 0;
}

